var iossim = require('./src/lib.js');
iossim.init();

exports = module.exports = iossim;
